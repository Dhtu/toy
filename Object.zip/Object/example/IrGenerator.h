#ifndef IR_GENERATOR
#define IR_GENERATOR

//这里提供IR生成功能的入口, 可以自己定义入口的格式, 入口的参数是我们的AST树, 所以参数类型要根据AstParser.h那边定义的来
//void IrGenerator();
//这个入口的输出我还没想好, 或许以文件IO或者文件流的形式, 明天讨论

#endif